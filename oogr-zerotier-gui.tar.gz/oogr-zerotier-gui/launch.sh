#!/bin/bash
cd ~/oogr-zerotier-gui/
sudo python3 zerotier_GUI.py
